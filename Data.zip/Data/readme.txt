
This CD set contains the Reuters Corpus.

Volume:                 1, English language, 1996-08-20 to 1997-08-19
Formatting version:     1
Release Date:           2000-11-03
Correction level:       0
Disk:                   1 of 2

For more information, contact research.corpus@reuters.com or see
http://www.reuters.com/researchandstandards/corpus/


